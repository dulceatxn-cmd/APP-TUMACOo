# Manual de Instalación — Tumaco Ruta (Android)

Aplicación offline-first para gestión de rutas de ventas, inventarios, pedidos y finanzas en Tumaco (Nariño, Colombia). Incluye mapa interactivo con descarga de calles y barrios desde OpenStreetMap.

## Requisitos

- Teléfono o tablet Android 8.0 (API 26) o superior.
- Cuenta de GitHub (gratuita).
- Conexión a internet solo para generar el APK la primera vez y para descargar el plano base de Tumaco.

## Paso 1: Generar el APK (en tu computadora o desde el celular con GitHub)

1. Entra a [https://github.com](https://github.com) e inicia sesión (o crea una cuenta gratuita).
2. Crea un **nuevo repositorio**:
   - Nombre sugerido: `tumaco-ruta`
   - Público o privado (da igual).
   - **No** marques "Add a README".
3. Sube **todo el contenido** de esta carpeta al repositorio (incluido el directorio oculto `.github`):
   - Opción fácil (desde computadora):
     - Descarga e instala [GitHub Desktop](https://desktop.github.com) o usa la web de GitHub arrastrando los archivos.
     - Asegúrate de subir también la carpeta `.github` (puede estar oculta en Windows/Mac; activa "mostrar archivos ocultos").
4. Ve a la pestaña **Actions** del repositorio.
5. Selecciona el workflow **Build APK** (a la izquierda).
6. Haz clic en **Run workflow** → **Run workflow** (botón verde).
7. Espera 5–10 minutos. El job pasará a color verde.
8. Entra a la ejecución terminada y descarga el artefacto llamado **tumaco-ruta-apk** (es un ZIP que contiene `app-debug.apk`).

> **Nota:** Cada vez que subas cambios a `www/index.html` (o a cualquier archivo), el workflow se puede volver a ejecutar automáticamente o manualmente.

## Paso 2: Instalar el APK en el celular Android

1. Transfiere el archivo `app-debug.apk` al teléfono (WhatsApp, Telegram, cable USB, Google Drive, etc.).
2. En el teléfono, abre el archivo APK.
3. Si aparece el aviso de seguridad:
   - Ve a **Ajustes → Seguridad** (o **Aplicaciones → Acceso especial**) y activa **Instalar apps de orígenes desconocidos** / **Permitir de esta fuente**.
4. Confirma la instalación.
5. Al abrir la app por primera vez:
   - Acepta el permiso de **Ubicación** (necesario para el GPS y marcar tiendas/calles).
   - Con internet activo, ve a la pestaña del **Mapa** y toca el botón **"Plano base OSM"** (solo una vez). Esto descarga las calles y barrios de Tumaco. Después la app funciona completamente sin conexión.

## Uso básico

- **Mapa**: visualiza y edita calles, barrios y tiendas. Puedes grabar una calle caminando con el GPS.
- **Tiendas**: registro de clientes con ubicación.
- **Inventario**: productos, stock, costos y precios.
- **Pedidos**: crear, entregar y cobrar pedidos.
- **Finanzas**: estado de resultados, rotación de inventario, cartera y gastos.

Los datos se guardan localmente en el teléfono (localStorage). Usa la opción de **Copia de seguridad** en Finanzas para exportar/importar todo en formato JSON.

## Actualizar la app

1. Modifica `www/index.html` (o los íconos).
2. Sube los cambios al repositorio de GitHub.
3. Vuelve a ejecutar el workflow **Build APK**.
4. Descarga el nuevo APK e instálalo encima del anterior (los datos se conservan).

## Solución de problemas

| Problema | Solución |
|----------|----------|
| El workflow falla | Revisa el log en Actions. Suele ser red temporal; vuelve a ejecutar. |
| No aparece el APK | Espera a que el job termine en verde y busca "Artifacts". |
| "Orígenes desconocidos" | Activa la opción solo para el navegador/archivo manager que usaste. |
| GPS no funciona | Verifica que el permiso de ubicación esté en "Permitir todo el tiempo" o "Solo al usar la app". |
| Mapa vacío | Toca "Plano base OSM" con internet. Si falla, revisa la conexión. |
| Windows Defender marca el ZIP | Falso positivo (solo contiene HTML/JS). Puedes revisar el código fuente. |

## Notas técnicas

- APK de depuración (debug): válido para uso personal y pruebas. No está firmado para Google Play.
- Tecnología: Capacitor 6 + WebView (HTML/CSS/JS puro).
- Permisos solicitados: ubicación precisa/aproximada, internet.
- Datos: 100 % locales. No hay servidores propios.

---
**Tumaco Ruta** — Hecho para facilitar las rutas de venta en Tumaco.
