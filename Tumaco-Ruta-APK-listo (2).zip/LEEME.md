# Tumaco Ruta — Generar e instalar el APK

Lee el archivo **MANUAL_INSTALACION.md** para instrucciones completas y detalladas.

## Resumen rápido

1. Crea un repositorio en GitHub y sube **todo** el contenido de esta carpeta (incluida `.github`).
2. Ve a **Actions → Build APK → Run workflow**.
3. Cuando termine (5-10 min), descarga el artefacto `tumaco-ruta-apk` (contiene `app-debug.apk`).
4. Transfiere el APK al celular Android, instálalo permitiendo "orígenes desconocidos" y acepta el permiso de ubicación.
5. En el mapa, toca **Plano base OSM** una sola vez (con internet) para descargar calles y barrios de Tumaco. Luego funciona offline.

Para actualizar: modifica `www/index.html`, sube y vuelve a ejecutar el workflow.

> Si Windows Defender marca el ZIP, es un falso positivo (solo hay HTML/JS). El código es legible en `www/index.html`.
